package Lab1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;





public class MyPanel extends JPanel {
	
	
//--------------------------New a ArrayList to Storage shape------------------
	static ArrayList<Shape> shapeList = new ArrayList<Shape>();
	
	
	
	
	
	/**
	 * This method creates two rectangles
	 * @return
	 */
//-------------------------Professor new shape style--------------------------
	/*
	private List<MyRectangle> createTwoRectangles(){
		Color myColor1 = new Color(231, 151, 44);
		MyRectangle rectangleShape1 = new MyRectangle (50, 95, 44, 48, myColor1);
		   
		Color myColor2 = new Color(131, 151, 44);
		MyRectangle rectangleShape2 = new MyRectangle (150, 138, 72, 45, myColor2);
		
		List<MyRectangle> shapeList = new ArrayList <MyRectangle>();
		shapeList.add(rectangleShape1);
		shapeList.add(rectangleShape2);
		
		return shapeList;
	}
	*/
	
	
	
	
	/**
	 * This method displays the created rectangles.
	 */
	
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D) g;
   
      //calling the method that creates shapes (rectangles)
      		
      for (Shape shape: shapeList) {
    	  
    	  g2d.setColor(shape.getColor());
    	  shape.draw(g2d);
    	  
 //---------------------------------Old constructor to check which shapes do we want to get----------------------------------
    	  //shape.drawShape(g2d);
    	  /*
    	  if(shape.getShapetype().equals("Rectangle")) {
    		  g2d.fillRect(shape.getUpperX(), shape.getUpperY(), shape.getWidth(), shape.getHeight());
  		}
  		
  		if(shape.getShapetype().equals("Cicle")) {
  			g2d.fillOval(shape.getUpperX(), shape.getUpperY(), shape.getWidth(), shape.getHeight());
  		}
  		*/	
      }
      //Refresh
      this.repaint();
   }
   
  
   
   /**
    * This is the main method of the class.
    * @param args
    */
   public static void main(String[] args) {
      MyPanel rects = new MyPanel();
      ShapeFactory ShapeFactory = new ShapeFactory();
      JFrame frame = new JFrame("Display Six shapes ");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
 //---------------------------Set button-----------------------------------------
      
      JButton b1 = new JButton("Load shapes");
		JButton b2 = new JButton("Sort shapes");
		rects.add(b1);
		rects.add(b2);
		
			
//---------------push button can get six shapes-------------------------------------
		b1.addActionListener(new ActionListener() { 
			  public void actionPerformed(ActionEvent e) {
				  
				  //Cicle Square Rectangle
				  Shape s1 = ShapeFactory.getShape(60,60,70,60,new Color(131, 21, 1),"Rectangle");
				  shapeList.add(s1);
				  
				  Shape s2 = ShapeFactory.getShape(120,120,95,95,new Color(131, 151, 44),"Cicle");
				  shapeList.add(s2);
				  
				  Shape s3 = ShapeFactory.getShape(220,220,35,50,new Color(218,112,214),"Rectangle");
				  shapeList.add(s3);
				  
				  Shape s4 = ShapeFactory.getShape(265,265,90,100,new Color(65,105,225),"Cicle");
				  shapeList.add(s4);
				  
				  Shape s5 = ShapeFactory.getShape(360,360,30,30,new Color(210,180,145),"Square");
				  shapeList.add(s5);
				  
				  Shape s6 = ShapeFactory.getShape(420,420,20,20,new Color(169,169,169),"Square");
				  shapeList.add(s6);
				  
				  //---------------------------------------Old constructor new shape-------------------
						
					/*
					
				  Shape b = new Shape(120, 120, 90,95, new Color(131, 151, 44),"Oval");
				  shapeList.add(b);
				  
				  Shape c = new Shape(200, 210, 80, 55, new Color(218,112,214),"Rect");
				  shapeList.add(c);
				  
				  Shape d = new Shape(280, 280, 90, 100, new Color(65,105,225),"Oval");
				  shapeList.add(d);
					
				  
				  Shape e1 = new Shape(380, 380, 60, 30, new Color(210,180,140),"Rect");
				  shapeList.add(e1);
				  
				  Shape f = new Shape(430, 430, 30, 30, new Color(169,169,169),"Oval");
				  shapeList.add(f);
					
				  */
					
			  } 
		});
//-----------------push button can sort shapes-------------------------------------		
		b2.addActionListener(new ActionListener() { 
			  public void actionPerformed(ActionEvent e) { 
				  
				  SortingTechnique.bubbleSort(shapeList);
				  
//-------------------------Successful sort area (Debug)----------------------------
				  /*
				  System.out.println(shapeList.get(0).getArea());
				  System.out.println(shapeList.get(1).getArea());
				  System.out.println(shapeList.get(2).getArea());
				  System.out.println(shapeList.get(3).getArea());
				  System.out.println(shapeList.get(4).getArea());
				  System.out.println(shapeList.get(5).getArea());
				  */
				  
	//--------------------------------Test b2 is working or not-----------------------------------
				  //MyRectangle a = new MyRectangle(500, 500, 44, 48, new Color(231, 151, 44),"Rect");
				 // shapeList.add(a);
	//---------------------------------sort help function to update x and y---------------------------------------- 
				  int x = 70; 
				  int y = 70;
				 for(int i = 0; i < shapeList.size(); i ++) {
					 
					 shapeList.get(i).setUpperX(x);
					 shapeList.get(i).setUpperY(y);
					 
					 x += 70;
					 
					 y += 70;
					 
					 
					 
				 }
				  
				  
				  
				  
			  } 
		});

      frame.add(rects);
      frame.setSize(600, 600);
      frame.setLocationRelativeTo(null);
      frame.setVisible(true);
   }
}