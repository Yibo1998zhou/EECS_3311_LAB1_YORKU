package Lab1;

import java.awt.Color;

public interface shapesInterface {
	//--------------------shape will be override-----------------------
	int getWidth() ;
	
	int getHeight();
	
	double getArea() ;
		
	Color getColor(); 
	
	String getShapetype();
	
	int getUpperX();
	
	int getUpperY();

}
