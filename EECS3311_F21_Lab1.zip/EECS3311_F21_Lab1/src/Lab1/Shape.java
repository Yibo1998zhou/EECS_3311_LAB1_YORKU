package Lab1;


import java.awt.Color;
//import java.awt.Graphics;
import java.awt.Graphics2D;

/*
 * Task:
 * Your class diagram should include the following classes:
 * 
o The Circle class: it represents a circle											   (Done)

o The Rectangle class: it represent a Rectangle										   (Done)

o The Square class: it represents a rectangle whose height and width are equal   	   (Done)

o The Shape class: class that embodies the generic concept of Shape					   (Done)

o The SortingTechnique class: it allows sorting shapes based on their surfaces         (Done)

o The ShapeFactory: it supports the instantiation of different Shapes 				   (Done)

o The classes allowing to display the shapes on an interface                           (Done)

o Other classes you may find relevant.
 * 
 * */
public class Shape implements shapesInterface {

	protected int upperX; 
	protected int upperY;
	protected int width;
	protected int height;
	protected Color shapeColor;
	private String shapetype;
	private double area;
	
	/**
	 * Class's constructor
	 * @param upperX
	 * @param upperY
	 * @param width
	 * @param height
	 * @param shapeColor
	 */
	public Shape (int upperX, int upperY, int width, int height, Color shapeColor) {
		this.upperX = upperX;
		this.upperY = upperY;
		this.width = width;
		this.height = height;
		this.shapeColor = shapeColor;
		this.shapetype = shapetype;
		
	}
	
	public Shape() {}
	


	public String getShapetype() {
		return shapetype;
	}



	public void setShapetype(String shapetype) {
		this.shapetype = shapetype;
	}



	

	
	/**
	 * Method to draw a rectangle
	 * @param form
	 */

	public  void draw(Graphics2D form) {
		//form.fillRect(upperX, upperY, width, height);
		//method to let child to Override
	}
	
    
    //getters
    public Color getColor() {
		return shapeColor;
	}
    
    public int getWidth() {
    	return width;
    }
    
    public int getHeight() {
    	return height;
    }
    
	public int getUpperX() {
		return upperX;
	}
	
	public int getUpperY() {
		return upperY;
	}
	
	//setters
	 public void setColor(Color aShapeColor) {
		 this.shapeColor = aShapeColor;
	 }
	 
	 public void setWidth( int width) {
		 this.width = width;
	 }
	    
	 public void setHeight(int height) {
		 this.height = height;
	 }
	 
	 public void setUpperX(int upperX) {
		 this.upperX = upperX;
	 }
		
	 public void setUpperY(int upperY) {
		 this.upperY = upperY;
	 }



	public double getArea() {
		return area;
	}



	public void setArea(double area) {
		this.area = area;
	}

 


}