package Lab1;

import java.awt.Color;

public class ShapeFactory extends Shape{
	
	
//---------------------------------Debug not use-----------------------------------
	public ShapeFactory(int upperX, int upperY, int width, int height, Color shapeColor) {
		super(upperX, upperY, width, height, shapeColor);
		// TODO Auto-generated constructor stub
	}
	//---------------------------------Debug not use-----------------------------------
	public ShapeFactory() {}
//---------------------------------Check which Shape and will be new shape-----------------------------------
	public Shape getShape(int UpperX, int UpperY, int Width, int Height, Color Color,String shapeType){
	      	
		  if(shapeType.equalsIgnoreCase("Cicle")){
	         return new Circle(UpperX,UpperY,Width,Height,Color);
	         
	      } else if(shapeType.equalsIgnoreCase("Rectangle")){
	         return new Rectangle(UpperX,UpperY,Width,Height,Color);
	         
	      } else if(shapeType.equalsIgnoreCase("Square")){
	         return new Square(UpperX,UpperY,Width,Height,Color);
	      }
	      
	      return null;
	   }

}
