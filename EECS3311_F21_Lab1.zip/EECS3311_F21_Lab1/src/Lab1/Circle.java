package Lab1;

import java.awt.Color;

import java.awt.Graphics2D;

public class Circle extends Shape {

	public Circle(int upperX, int upperY, int width, int height, Color shapeColor) {
		
		//call Shape constructor
		super(upperX, upperY, width, height, shapeColor);
		// TODO Auto-generated constructor stub
	}
	//-------------------------------Caclculate are to help buuble to sort------------------
	public double getArea() {
		
		double r = this.getWidth() * 0.5;
		return Math.pow(r, 2) * Math.PI;
		
	}
	
	//-------------------------------Draw a rectangle in swing------------------
	public  void draw(Graphics2D form) {
		
		form.fillOval(this.getUpperX(), this.getUpperY(), this.getWidth(),this.getHeight());
			
		
	}
	
	


}
