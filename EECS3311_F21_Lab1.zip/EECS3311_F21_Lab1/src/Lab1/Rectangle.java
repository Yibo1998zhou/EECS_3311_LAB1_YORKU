package Lab1;

import java.awt.Color;
import java.awt.Graphics2D;

public class Rectangle extends Shape{
	// ------------------------------call shape---------------------------------
	public Rectangle(int upperX, int upperY, int width, int height, Color shapeColor) {
		super(upperX, upperY, width, height, shapeColor);
		// TODO Auto-generated constructor stub
	}
	//-------------------------------Caclculate are to help buuble to sort------------------
	public double getArea() {
		
		return this.getWidth() * this.getHeight();
		
	}
	//-------------------------------Draw a rectangle in swing------------------
	public  void draw(Graphics2D form) {
		
		form.fillRect(this.getUpperX(), this.getUpperY(), this.getWidth(),this.getHeight());
			
		
	}

}
