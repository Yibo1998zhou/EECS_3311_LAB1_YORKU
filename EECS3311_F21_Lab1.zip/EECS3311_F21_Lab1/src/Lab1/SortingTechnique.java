package Lab1;

import java.util.ArrayList;

public class SortingTechnique {
	 public static void bubbleSort(ArrayList<Shape> shapes) {
		 //-------------------Debug--------------------
		 //System.out.println(shapes.get(0).getUpperX() < shapes.get(1).getUpperX());
		//--------------------Debug--------------------
			   /*
			   System.out.println(shapes.get(0).getArea()); 
			   System.out.println(shapes.get(1).getArea()); 
			   System.out.println(shapes.get(2).getArea()); 
			   System.out.println(shapes.get(3).getArea()); 
			   */
		//-----------------bubbleSort Test sample--------
			   /*public static void bubbleSort(int[] arr) {
		 
		    	for (int i = 1; i < arr.length; i++) {
		    
		        for (int j = 0; j <= arr.length -1 - i; j++) {
		            if (arr[j] > arr[j + 1]) {
		                int temp;
		                temp = arr[j];
		                arr[j] = arr[j + 1]; 
		                arr[j + 1] = temp;
		            }
		        }
		    }*/
				for (int i = 0; i < shapes.size()-1; i++)
					for (int j = 0; j < shapes.size()-i-1; j++)
						if (shapes.get(j).getArea() > shapes.get(j+1).getArea())
						{
							//System.out.println(shapes.get(0).getArea() < shapes.get(1).getArea());
							Shape temp = shapes.get(j);					
							shapes.set(j, shapes.get(j+1));
							shapes.set(j+1, temp);
						}
						
		   }
}
